# v3.1.1
- updated `BepInEx` to v5.4.19

# v3.1.0
- added `RTAutoSprintAddon` in order to fix issue with cancelling Artificer's Flamethrower; provides other advanced functionality
- reverted blue portal base spawn chance in `EphermeralCoins` to match vanilla
- shortened enemy ping back to default; not sure how well `ChensMinionRetarget` is working, and being unable to ping an enemy again quickly felt awkward; might revert this at a later point

# v3.0.0
- full reset of the pack
- started storing the `.dll` files of the mods
  - originally didn't do this because I didn't want my GitHub to be the place to download files, but I've since learned the hard way that some mods will just disappear; I still don't recommend using this page as your source
- this version of the pack is primarily QOL mods with a couple of placeholders and small balance tweaks
  - my intentions at this point are to resurrect some of the old mods that I am feeling the loss of, and simply get a feel for the game again before messing with balance too much
