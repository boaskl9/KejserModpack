# Info
Can't live without this, so here it is for other peeps.

# Installation
R2modman is recommended. 
Manual:
1 - Download and install BepInExPack
2 - Extract the "InstantTeleporter" dll to your plugins folder
3 - Have fun!

# Changelog
1.0.5 - Fixed errors when killing a custom boss spawn outside of the teleporter event.

1.0.4 - Fixed errors on custom maps that don't have a teleporter.

1.0.3 - No longer throws errors when fighting Mithrix and fixed A Moment Whole softlock. 

1.0.1 - No longer activates when killing AWU.

1.0.0 - Release