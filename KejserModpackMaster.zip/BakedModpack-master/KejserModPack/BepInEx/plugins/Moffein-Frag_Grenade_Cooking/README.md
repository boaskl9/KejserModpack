Reworks Commando's Frag Grenades by making them cookable.

Instead of having 2 unreliable grenades with iffy damage, Commando now has a single strong grenade that can be cooked to detonate midair.

All players need the mod.


## Changes

- Damage increased 700% -> 1400%
- Cooldown increased 5s -> 10s
- Stock reduced 2 -> 1

## Installation
Place Frag_Grenade_Cooking.dll in /Risk of Rain 2/BepInEx/plugins/
Config can be found in /Risk of Rain 2/BepInEx/config/

## Changelog

1.1.2

- Added missing R2API submodule dependency. This should fix errors when running this mod on minimal mod setups.

1.1.1

- Fixed skill description listing damage as 1200% instead of 1400%. Description now changes based on config setting.
- Blast radius increased 11m -> 14m to match MandoGaming.
- Added blast radius config option.


1.1.0

- Enabled sweetspot falloff by default.
- Increased damage 1200% -> 1400%
- Cooldown now ticks down while cooking.
- Made most things configurable.

1.0.0

- Release