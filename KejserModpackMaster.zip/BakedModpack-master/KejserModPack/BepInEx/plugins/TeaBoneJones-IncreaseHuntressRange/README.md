# Increase Huntress Range

Increase the range of Huntress every time you level up. Or turn on God Mode and increase the range to encompass the whole map.

## Config

God Mode: Set Huntress range to 10,000 meters. Encompasses the whole map, so any enemy that is visible can be shot at.
Scale Factor: Set how much the range increases (in meters) each level. Recommended: 3 (but I'm not your dad) 

## Known Issues

None so far. But if you find any, create a new issue on the github:
https://github.com/tvegh/IncreaseHuntressRange/issues

## Changelog

- 1.0.0: First version. I'm sure there will be no others, because my code is always flawless.
