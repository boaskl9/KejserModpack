# TrueDoubleTap

Risk of Rain 2 mod to give players a short-duration cloak effect on spawning into a level

 - Gain a cloak effect the same as the Old War Stealth Kit gives
 - Duration (default 4s) is configurable in `/BepInEx/config/com.Timmeh42.StealthySpawn.cfg`

### Installation

- Requires BepInEx
- Copy the dll to the BepinEx plugins folder
